﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Resume_Build
{
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {

            try
            {
                if (IsLoginFormValide())
                {
                    SqlConnection con = new SqlConnection("server=SANGAMESH; database=ResumeBuilder; integrated security=true;");
                    SqlCommand cmd = new SqlCommand("select * from tbl_User where email=@email and password=@password ", con);
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    con.Open();
                    int i = 0;
                    i = cmd.ExecuteNonQuery();
                    con.Close();

                    if (dt.Rows.Count > 0)
                    {
                        Response.Write("<script> alert('Login Failed...') </script>");
                        txtEmail.Text = string.Empty;
                        txtPassword.Text = string.Empty;
                        Response.Redirect("HomePage.aspx");
                        Response.Write("<script> alert('Login Successfull...') </script>");

                    }
                    else
                    {
                        Response.Write("<script> alert('Login Failed...') </script>");
                        txtEmail.Text = string.Empty;
                        txtPassword.Text = string.Empty;
                        txtEmail.Focus();
                    }
                    con.Close();
                }


            }
            catch (Exception ex)
            {
                Response.Write("<script> alert('Login Failed.'" + ex + "); </script>");
            }

        }

        //Server Side Login Form Validation
        private bool IsLoginFormValide()
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;


            if (email == "" && password == "" || email == "" || password == "")
            {

                Response.Write("<script> alert('Feild are empty')</script>");

                txtEmail.Focus();

                return false;

            }
            else if (email.Length <= 3 || password.Length <= 3)
            {
                Response.Write("<script> alert('Email and Password Should be minimum 4 Character')</script>");
                txtEmail.Focus();
                return false;
            }
            return true;


        }

    }
}