﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Resume_Build
{
    public partial class RegForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonRegister_Click(object sender, EventArgs e)
        {
            if (IsRegFormValide())
            {

            }
        }


        //Server Side Registration Form Validation
        private bool IsRegFormValide()
        {
            string email = txtRegEmail.Text;
            string password = txtRegPassword.Text;
            string name = txtName.Text;
            string phone = txtPhone.Text;

            if (email == "" && password == "" || email == "" || password == "" || phone == "" || name == "")
            {

                Response.Write("<script> alert('Feild are empty')</script>");
                txtRegEmail.Focus();

                return false;
            }
            else
            {
                if (email.Length <= 3)
                {
                    Response.Write("<script> alert('Email Should be minimum 4 Character')</script>");
                    txtRegEmail.Focus();

                    return false;
                }
                else if (password.Length >= 18 || password.Length <= 3)
                {
                    Response.Write("<script> alert('Password should be minimum 4 character and maximum 18 character')</script>");
                    txtRegPassword.Focus();

                    return false;
                }
                else if (phone.Length < 10 || phone.Length > 10)
                {
                    Response.Write("<script> alert('Phone Number Should be 10 Characters')</script>");
                    txtPhone.Focus();

                    return false;
                }
            }


            return true;
        }
    }
}