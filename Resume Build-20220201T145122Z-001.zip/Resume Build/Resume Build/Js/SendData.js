﻿
//Add and remove fields
function create_tr(table_id, ch) {
    let table_child = document.getElementById(ch);
    let table_body = document.getElementById(table_id),
        first_tr = table_body.firstElementChild
    tr_clone = first_tr.cloneNode(true);

    table_body.append(tr_clone);

    clean_first_tr(table_body.firstElementChild,table_child.firstElementChild);
}

function clean_first_tr(firstTr,secondTr) {
    let children = firstTr.children;
    let secondChild = secondTr.children;

    children = Array.isArray(children) ? children : Object.values(children);
    children.forEach(x=> {
        if (x !== firstTr.lastElementChild) {
            x.firstElementChild.value = " ";
            
        }
    });

        secondChild = Array.isArray(secondChild) ? secondChild : Object.values(secondChild);
        secondChild.forEach(y=> {
            if (y !== secondTr.lastElementChild) {
                y.firstElementChild.value = " ";
               
            }
    });
}



    function remove_tr(This, table_id, child)
    {
    let table_body = document.getElementById(table_id);
    let tr = document.getElementById(child);

    if (table_body.childElementCount == 1) {
        alert("You Don't have Permission to Delete This!!");
    } else {
        tr.remove();
    }
}




//Show image 
function showPreview(event) {
    if (event.target.files.length > 0) {
        var src = URL.createObjectURL(event.target.files[0]);
        var preview = document.getElementById("file-ip-1-preview");
        preview.src = src;
        preview.style.display = "block";
    }
}

