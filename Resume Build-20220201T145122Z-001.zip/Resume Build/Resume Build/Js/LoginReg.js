﻿
function login()
{
    document.querySelector(".reg-bg-model").style.display = "none";
    var loginBtn = document.getElementById("loginBtn");
    loginBtn = document.querySelector(".bg-model").style.display = "flex";

}

function funclose()
{
    var closenBtn = document.getElementById("close");
    closenBtn = document.querySelector(".bg-model").style.display = "none";

}

function reg()
{

    document.querySelector(".bg-model").style.display = "none";
    var regBtn = document.getElementById("regBtn");
   regBtn = document.querySelector(".reg-bg-model").style.display = "flex";

}

function regfunclose()
{
    var closenBtn = document.getElementById("Regclose");
    closenBtn = document.querySelector(".reg-bg-model").style.display = "none";

}

function navRegistration()
{
    document.querySelector(".bg-model").style.display = "none";
    var sidNav = document.getElementById("side-nav")
    sidNav.style.right = "-260px";
    menu.src = "Images/menu.png";
    var regBtn = document.getElementById("navRegistration");
    regBtn = document.querySelector(".reg-bg-model").style.display = "flex";
}

function navLogin()
{
    document.querySelector(".reg-bg-model").style.display = "none";
    var sidNav = document.getElementById("side-nav")
    sidNav.style.right = "-260px";
    menu.src = "Images/menu.png";
    var loginBtn = document.getElementById("navLogin");
    loginBtn = document.querySelector(".bg-model").style.display = "flex";

}


//Login Validation 
function LoginValidation()
{
    var email = document.getElementById("txtEmail").value;
    var password = document.getElementById("txtPassword").value;
    
    if (email == "" && password == "" || email == "" || password == "") {
       
        document.getElementById("msg").innerHTML = "Feild are empty";
        
        document.getElementById("txtEmail").focus();
       
        return false;
        
    }
    else if (email.length <= 3 || password.length <= 3)
    {
        document.getElementById("msg").innerHTML = "Email and Password Should be minimum 4 Character";
        document.getElementById("txtEmail").focus();
        return false;
    }
    
}


// Registarion Validation 
function RegValidation()
{
    var regName = document.getElementById("txtName").value;

    var regEmail = document.getElementById("txtRegEmail").value;

    var regPhone = document.getElementById("txtPhone").value;

    var regPassword = document.getElementById("txtRegPassword").value;

    if (regEmail == "" && regPassword == "" || regEmail == "" || regPassword == "" || regPhone == "" || regName == "")
    {

        document.getElementById("Regmsg").innerHTML = "Feild are empty";

        document.getElementById("txtRegEmail").focus();

        return false;
    }
    else{
        if (regEmail.length <= 3)
        {
            document.getElementById("Regmsg").innerHTML = "Email Should be minimum 4 Character";
            document.getElementById("txtEmail").focus();

            return true;
        }
        else if (regPassword.length >= 18 || regPassword.length <= 3)
        {
            document.getElementById("Regmsg").innerHTML = "Password should be minimum 4 character and maximum 18 character";
            document.getElementById("txtPassword").focus();

            return false;
        }
        else if (regPhone.length < 10 || regPhone.length > 10)
        {
            document.getElementById("Regmsg").innerHTML = "Phone Number Should be 10 Characters";
            document.getElementById("txtPhone").focus();

            return false;
        }
    }
    
    
}
